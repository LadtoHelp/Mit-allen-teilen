﻿<# 


69000 - Unable to reach blob storage
69001 - No Printers in source.
#>

[CmdletBinding()]
Param (
    [Parameter(Mandatory = $false)]
    [ValidateSet('Install', 'Uninstall', 'Repair')]
    [String]$DeploymentType = 'Install',
    [Parameter(Mandatory = $false)]
    [ValidateSet('Interactive', 'Silent', 'NonInteractive')]
    [String]$DeployMode = 'Interactive',
    [Parameter(Mandatory = $false)]
    [switch]$AllowRebootPassThru = $false,
    [Parameter(Mandatory = $false)]
    [switch]$TerminalServerMode = $false,
    [Parameter(Mandatory = $false)]
    [switch]$DisableLogging = $false
)

Try {
    ## Set the script execution policy for this process
    Try {
        Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Scope 'Process' -Force -ErrorAction 'Stop'
    }
    Catch {
    }

    ##*===============================================
    ##* VARIABLE DECLARATION
    ##*===============================================
    ## Variables: Application
    [String]$appVendor = 'RLS'
    [String]$appName = 'Forms Printer setup'
    [String]$appVersion = '2.0'
    [String]$appArch = ''
    [String]$appLang = 'EN'
    [String]$appRevision = '01'
    [String]$appScriptVersion = '1.0.0'
    [String]$appScriptDate = 'XX/XX/20XX'
    [String]$appScriptAuthor = "Leroy D'Souza"


    ##*===============================================
    ## Variables: Install Titles (Only set here to override defaults set by the toolkit)
    [String]$installName = ''
    [String]$installTitle = ''

    ##* Do not modify section below
    #region DoNotModify

    ## Variables: Exit Code
    [Int32]$mainExitCode = 0

    ## Variables: Script
    [String]$deployAppScriptFriendlyName = 'Deploy Application'
    [Version]$deployAppScriptVersion = [Version]'3.9.3'
    [String]$deployAppScriptDate = '02/05/2023'
    [Hashtable]$deployAppScriptParameters = $PsBoundParameters

    ## Variables: Environment
    If (Test-Path -LiteralPath 'variable:HostInvocation') {
        $InvocationInfo = $HostInvocation
    }
    Else {
        $InvocationInfo = $MyInvocation
    }
    [String]$scriptDirectory = Split-Path -Path $InvocationInfo.MyCommand.Definition -Parent

    ## Dot source the required App Deploy Toolkit Functions
    Try {
        [String]$moduleAppDeployToolkitMain = "$scriptDirectory\AppDeployToolkit\AppDeployToolkitMain.ps1"
        If (-not (Test-Path -LiteralPath $moduleAppDeployToolkitMain -PathType 'Leaf')) {
            Throw "Module does not exist at the specified location [$moduleAppDeployToolkitMain]."
        }
        If ($DisableLogging) {
            . $moduleAppDeployToolkitMain -DisableLogging
        }
        Else {
            . $moduleAppDeployToolkitMain
        }
    }
    Catch {
        If ($mainExitCode -eq 0) {
            [Int32]$mainExitCode = 60008
        }
        Write-Error -Message "Module [$moduleAppDeployToolkitMain] failed to load: `n$($_.Exception.Message)`n `n$($_.InvocationInfo.PositionMessage)" -ErrorAction 'Continue'
        ## Exit the script, returning the exit code to SCCM
        If (Test-Path -LiteralPath 'variable:HostInvocation') {
            $script:ExitCode = $mainExitCode; Exit
        }
        Else {
            Exit $mainExitCode
        }
    }

    #endregion
    ##* Do not modify section above


    $IntuneDetectionKey = "HKEY_LOCAL_MACHINE\SOFTWARE\RLS\$($appName)"


    ##*===============================================
    ##* END VARIABLE DECLARATION
    ##*===============================================

    #region Create the app on PC for re-use
        #COPY to LOCAL Computer to perform as an App
        
        If (!(Test-Path $($IntuneDetectionKey))) {
        
            #Copy the Payload
            Robocopy "$($PSScriptRoot)" "C:\Program Files (x86)\RLS\$($appName)\$($appVersion)" /E /J
            
            #Create the scheduled task
            ."$dirSupportFiles\Create-PrinterTaskSchedule.ps1"

            #Create shortcut for the user


            $RLSPrinterIconbase64 = 'iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAADCElEQVRoge1ZyW4TQRCdCYj9AFwsg7exLYH8BYjNEkJcEN8AyZELNwSOIgjigjjDJ8CJJD8BKCBAHBAhQRxYzlngBCbwHq6RhsGe7unpWVBcUmlGSXfVe13VNdVtxxnLFpVKpXLQ87wp6AJ0CfpNlO/zzWZzslarHcgb5z8C4LsBcLrRaKzj+StKMWYNzx7n5I37j1Sr1UMA9UwFfIi+QkRquYJvt9sVAPlsAN6PxidE4nAu4CVtXkQBbLVax7HKJxUkntfr9V2ZE4DjGdUK+2NV40DyWmJA5XJ5D4zdArD3ePZHrNZrjmW10dmwugS4sRNVJwH/VMPRjACa0slxXQJUpNElYwJceR0nCPUZGb9gmwB0zpiApI1v6Hqn09mhGP8uBQJLxgSCOa8CLwQ2QuE/ZuDzVCg9N8zQO44bMLSpMyFMgOUyrlPY6BoRQB6fwOAH/IhAf2iG13dSF+fZp1C3290Ox/fiAB6yic8LoHnbBIDtkSpk95OAFyc3JIqTKRC4OBJ8eMMkILAMc658yNY0CLjif1MxdhWFYH8UgYc2CAiJ02KzZ4sAbF6NTB8M+mKRwCJMTrABYyMWNZYFgxVKZU/ZzHkjepsEepl22QqzmiVYjI88T0SCFwI2wdPxd+g52pYDzaKBnZfaBxrbBITEOlOE9pkCbIl1NjZ0lTmPw9BOzpU95WZOIBCJK74ftsTsKr3Bd+It/veVynfoHEtloNq4nEsbeJ/IhUCACFPoglY6DPCcDRaA3AkE9A30jgA8UiqV9qI53IdVP8o9g7/f9QZXLH/NA8RtRSFgpEWKwJYlYDWFlCeyKOFcT6PNSI1AEvC+sMbH8clW3xqBpOANfSojoN0L5UDgp6PaxKFbh6IR+KBjbLaoBLC4t5XG5CL2SdEIsAXhraCWQSFxE5NWovZEBgT6ktKz2uDjOLNiMCWbmTrLmkCsq0WVhD5kfRsYIyVUZnsWWonpwEZdtol1qMQps3HVvwxLVeKU2ZjgH2f2c6pumdVQlskVrnxhfgsey1j+M/kNVRSE4TdDnccAAAAASUVORK5CYII='

            $RLSPrinterIconFile = "$envSystem32Directory\RLSPrinterIcon.png"
            $bytes = [Convert]::FromBase64String($RLSPrinterIconbase64)
            [IO.File]::WriteAllBytes($RLSPrinterIconFile, $bytes)



            New-Shortcut -Path "$envProgramData\Microsoft\Windows\Start Menu\Configure Forms Printer.lnk" -TargetPath "$exeSchTasks" -Arguments "/TN `"\RLS\Configure Forms Printer`"" -IconLocation "%SystemRoot%\System32\SHELL32.dll" -IconIndex 59 -Description 'Configures the Forms Printers on the device' -WorkingDirectory "$envHomeDrive\$envHomePath"
        }
    #endRegion Create the app on PC for re-use


    #Import Site Data
    Write-Log -Message "Importing Site Data Information" -WriteHost $true -ScriptSection Initialization

    #Download csv from storage

    #Download via URI using SAS
    $BlobUri = [System.UriBuilder]'https://stmgmtprdasemem01.blob.core.windows.net/site-lists/Sites.csv'
    $BlobSasToken = 'sp=r&st=2023-09-22T00:29:42Z&se=2023-10-22T07:29:42Z&spr=https&sv=2022-11-02&sr=b&sig=JQnocw23S9Ed29zyRBI0HzKfZbODEyzUbk0v%2FpujHXs%3D'
    $BlobUri.Query = $BlobSasToken
    $FullUri = "$($BlobUri.Uri)" #.AbsoluteUri
    $Sitesdatafile = "$envProgramData\RLS\SiteList\sites.csv"

    #Test if connectivity to Blob
    if (
    (Test-NetConnection $BlobUri.Host -Port $BlobUri.Port).TcpTestSucceeded  ) {

        Write-Log -Message "URI accessible. Checking file details" -Severity 1
        
        #Get source file modified date
        $SitesdatafilelastModified = (Invoke-WebRequest -Uri $FullUri -UseBasicParsing).Headers.'Last-Modified' | Get-Date
        Write-Log -Message "Data file last modified $($SitesdatafilelastModified | Out-String)" -Severity 1



    }
    else {
        
        Write-Log -Message "Unable to connect to host: $($BlobUri.Host). Checking if file available locally" -Severity 2
        #Check if File Locally available
        if (!(Test-Path $Sitesdatafile -ErrorAction SilentlyContinue)) {
            Write-Log -Message "Unable to connect to host: $($BlobUri.Host)" -Severity 3
            Exit-Script -ExitCode 69000
        }
        else {
            Write-Log -Message "Using locally cached file" -Severity 2
        }
    }

    #Create Target directory for the sites file
    if (!(Test-Path (Split-Path $Sitesdatafile) -ErrorAction SilentlyContinue)) {
        mkdir "$(Split-Path $Sitesdatafile)"
    }
    
    #Begin Download
    #(New-Object System.Net.WebClient).DownloadFile($FullUri, $Sitesdatafile)
    Write-Log -Message "Connecting to $($FullUri)" -Severity 1
    Invoke-WebRequest -Uri $FullUri -OutFile "$($Sitesdatafile)" -UseBasicParsing


    #Import sites data to a lookuptable
    $SiteData = Import-Csv "$($Sitesdatafile)" | # (Join-Path "$($envProgramData)\RLS\SiteList" Sites.csv) |
    Select-Object *, @{
        'Name'       = 'NetIPAddress_obj'
        'Expression' = { [IPAddress]$_.SiteNetIPAddress }
    }, @{
        'Name'       = 'NetMask_obj'
        'Expression' = { [IPAddress]$_.Sitenetmask }
    }


    If ($deploymentType -ine 'Uninstall' -and $deploymentType -ine 'Repair') {
        ##*===============================================
        ##* PRE-INSTALLATION
        ##*===============================================
        [String]$installPhase = 'Pre-Installation'

        #Get computer's current site via IP Address
        # Get-NetAdapter |  ?{$_.MediaConnectionState -eq 'connected' -and $_.InterfaceDescription -notmatch 'Hyper-V Virtual Ethernet'} | fl

        #Get Computer's IP address
        $ipaddress = Get-CimInstance  Win32_NetworkAdapterconfiguration -Filter "ipENABLED = 'True'" |
        Select-Object -First 1 |
        Select-Object -ExpandProperty IPAddress |
        Select-Object -First 1 |
        ForEach-Object {
            [IPAddress]$_
        }

        Write-log -Message "Computer IP address: $($ipaddress.IPAddressToString)"


        #Serach for Site based on Computer IP from sites data csv 
        $Source = ForEach ($datum in $SiteData  ) {
            
            If ($datum.NetIPAddress_obj.Address -eq (
                    $ipaddress.Address -band $datum.NetMask_obj.Address
                )
            ) {
                $datum
                Break
            }
        }

        if ($Source) {
            Write-log -Message "Found Site: $($Source.sitename)"
        }
        else {
            Write-log -Message "NO SITE Found. Default to prompt" -Severity 2
        }




        ##*===============================================
        ##* INSTALLATION
        ##*===============================================
        [String]$installPhase = 'Installation'


        ## <Perform Installation tasks here>
        $SourceForms_Printers = ($Source.Forms_Printer -split ';')
        Write-log -message "Found $($SourceForms_Printers.count) printers"

        if ($SourceForms_Printers.count -gt 1 ) {
            #Need manual selection of printers to set as default
            Write-Log -Message "More than one forms printer has been detected. Need to confirm default printer."
            $MultiplePrinters = $true
        }
        
        #Perform Printer Map
        ForEach ($SourceForms_Printer in $SourceForms_Printers) {


            #Test if Printer available
            #Code to be put here

            #Construct UNC
            $FormsPrinterURI = "\\$($source.forms_printer_servername)\$($SourceForms_Printer)"

            Write-log -message "Processing $($SourceForms_Printer) URL $FormsPrinterURI "

            #Check if printer already installed
            Write-log -message "Checking if  $($FormsPrinterURI) mapped "
            if (Get-Printer -Name "$FormsPrinterURI") {

                "Printer already installed"

            }
            else {

                Execute-Process -Path "$env:windir\system32\rundll32.exe" -Parameters "printui.dll,PrintUIEntry /ga /n$($FormsPrinterURI)" -PassThru -ExitOnProcessFailure:$false

                #Start-Process "$env:windir\system32\rundll32.exe" -args "printui.dll,PrintUIEntry /ga /n$($FormsPrinterURI)" -NoNewWindow -PassThru -Wait
            
                Show-InstallationProgress

                Execute-ProcessAsUser -Path "$env:windir\system32\rundll32.exe" -Parameters "printui.dll,PrintUIEntry /in /n$($FormsPrinterURI)"
            }

        }

        #Set Default Printer

        $TargetDefaultPrinter = Get-CimInstance -Class Win32_Printer -Filter "Name='$(TargetDefaultPrinter)'"
        Invoke-CimMethod -InputObject $TargetDefaultPrinter -MethodName SetDefaultPrinter


        



        ##*===============================================
        ##* POST-INSTALLATION
        ##*===============================================
        [String]$installPhase = 'Post-Installation'

        ## <Perform Post-Installation tasks here>
        Set-RegistryKey -Key $IntuneDetectionKey -Name 'Version' -Type 'string' -Value $appVersion


    }
    ElseIf ($deploymentType -ieq 'Uninstall') {
        ##*===============================================
        ##* PRE-UNINSTALLATION
        ##*===============================================
        [String]$installPhase = 'Pre-Uninstallation'



        ##*===============================================
        ##* UNINSTALLATION
        ##*===============================================
        [String]$installPhase = 'Uninstallation'

    

        ## <Perform Uninstallation tasks here>


        ##*===============================================
        ##* POST-UNINSTALLATION
        ##*===============================================
        [String]$installPhase = 'Post-Uninstallation'

        ## <Perform Post-Uninstallation tasks here>


    }
    ElseIf ($deploymentType -ieq 'Repair') {
        ##*===============================================
        ##* PRE-REPAIR
        ##*===============================================
        [String]$installPhase = 'Pre-Repair'



        ##*===============================================
        ##* REPAIR
        ##*===============================================
        [String]$installPhase = 'Repair'

   

        ##*===============================================
        ##* POST-REPAIR
        ##*===============================================
        [String]$installPhase = 'Post-Repair'

        ## <Perform Post-Repair tasks here>


    }
    ##*===============================================
    ##* END SCRIPT BODY
    ##*===============================================

    ## Call the Exit-Script function to perform final cleanup operations
    Exit-Script -ExitCode $mainExitCode
}
Catch {
    [Int32]$mainExitCode = 60001
    [String]$mainErrorMessage = "$(Resolve-Error)"
    Write-Log -Message $mainErrorMessage -Severity 3 -Source $deployAppScriptFriendlyName
    Show-DialogBox -Text $mainErrorMessage -Icon 'Stop'
    Exit-Script -ExitCode $mainExitCode
}
